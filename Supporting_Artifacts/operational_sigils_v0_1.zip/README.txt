Operational Sigil Set — Yggdrasil Geo‑Grammaton (v0.1)

Files:
01_Horizon_Sigil.svg         — Horizon‑Σ (cloud/bolt/ground). Two dials: η (openness), κ (compression).
02_Seal_Crown.svg            — Seal (Crown): mirror‑seal; cadence bar (seal ≥ change).
03_Glue_Bridge.svg           — Glue (Bridge): cross‑scope boundary with pause/delete/rectify controls.
04_Concord_Wreath.svg        — Concord (Wreath): treaty/federation; dual keys; neutral forum dot.

Rails (dual constraints):
05_Rail_Open_Corridors.svg   — Open Corridors: lawful speech channels through a typed gate.
06_Rail_Standards_Commons.svg— Standards Commons: units/measure; shared schemas.
07_Rail_Rescue_First.svg     — Rescue First: undo/rollback before scale.
08_Rail_Responsible_Replication.svg — Proof‑paced growth; rate governor.
09_Rail_No_Dispossession.svg — Equity floor; locked base (no taking without consent).
10_Rail_Neutral_Forum.svg    — Public minutes; visible appeal ("bell").

Usage:
• Monochrome, stroke‑only SVGs; scale from 24px to poster.
• Pair with plain‑language tooltips + receipt links.
• Neutral UI—no sacred styling; let receipts lead.

License: CC‑BY 4.0 — attribute “Yggdrasil Geo‑Grammaton Sigils (v0.1)”.